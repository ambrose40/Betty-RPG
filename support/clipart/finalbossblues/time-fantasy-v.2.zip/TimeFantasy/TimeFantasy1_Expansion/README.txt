Hello! Thanks for updating the Time Fantasy graphics pack. Enjoy these
additional graphics.

This update includes:

- animation poses for 64 characters in the Time Fantasy graphics pack
- a sprite sheet of animated spikes and switches to use in puzzles
- 4 window skins that match the retro pixel feel of the TF style


ALSO:

Some of the graphics included in this update have been
previously released for free on the timefantasy website.

They are included in this update for your convenience. 

These are:
	-bonus1
	-animals1
	-tiles_kitchen
	-trees

The kitchen tiles and the trees are loose tiles, so in order to use them in 
RMVX/Ace, you�ll have to edit them into a tileset. They�re 
already arranged in alligned 32�32 tiles, so all you need to 
do is plug them into whichever tileset you want to use them with.

To edit or use them in RM2K3, just shrink them by 50% in an 
image editing program. Make sure to check �nearest neighbor� 
to keep the pixels clean.

Have fun. :)