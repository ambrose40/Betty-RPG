-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY :: STEAMPUNK TILESET EXPANSION
-==-=- -==-=- -==-=- -==-=- -==-=-

This is the BETA RELEASE for PATREON (so i'm gonna be lazy with this readme)

This version includes sets in the 100% sheets and 300% sheets formatted for use in RPGMAKER MV.

Let me know if anything doesn't work. Thanks!

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------

