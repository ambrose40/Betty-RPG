The files in this folder are from an earlier version of WOLF RPG Editor.
They are provided from the developer, but they are not necessary for game creation.

Unless you plan to use or learn from these files, we highly recommend creating and using your own images.
We hope you learn from what is provided in the "Full Package" and "Start Package".

Please give credit to the artists should you use their images in their original form.

   Thank you,
              Widderune

|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

[Other Data Collection: Version 1 Resources]

[Monster Graphics]
  Isooki (http://www.geocities.jp/iso015/)[Japanese but the website is nonexistent]
  Suu (http://suulabo.dw.land.to/)[Japanese but the website is nonexistent]

[Map Graphics]
  Nori (http://nega.client.jp/)[Japanese]
  * Parts by the following used from the WOLF Editor Wiki and Resource Request Thread.
    Yuuto, RETAW, Suu, Karekusa, Sumika, Urocchi, Rikugame

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||