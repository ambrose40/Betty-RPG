This is a Common Event that allows you to display a password (combination) entry screen.
1 to 6 digits are supported.
Numbers output with a PIN are treated as 1 to 6 digits.
Example: The entered PIN is
Assign �"2�", �"3�", �"6�" �-> 236 to any variable
"5" "1" "0" "7" "1" �-> 51071 is assigned to any variable
I think that it is not difficult to use, but the explanation is put in the folder with the image once.
It also avoids image numbers that are already in use.
Remodeling of this common and secondary distribution of the modified version is allowed.
* When using this common, please put the "PIN Event Up&Down.png" in the Picture folder of the Data folder.