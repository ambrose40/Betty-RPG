-=-=-=- -==-=- -==-=- -==-=- -==-=-
       ::  TIME FANTASY  ::
:: STEAMPUNK TILESET EXPANSION :: 
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading this Time Fantasy asset pack.

This set includes tilesets for a STEAMPUNK setting. It includes:
 - city buildings in the style of the industrial revolution (three color variations)
 - steam trains (outside and inside)
 - Victorian-inspired interiors
 - dungeons full of pipes, valves, and clockwork mechanisms
 - and many more additional object tiles
 - Also: animated smoke and steam effects and animated gears

Note: This release also includes the Sewer tileset as a free bonus (in a separate folder).

-------------------------

This set is an expansion for the Time Fantasy RPG assets. It's compatible with all other graphics that I release in my Time Fantasy style (particularly the "Future Fantasy" set, which includes similarly-themed city and factory tiles).

Included are versions formatted for use in RPGMaker VX/Ace and RPGMaker MV, as well as a regular tile-sheet based on a 16x16 grid.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------

