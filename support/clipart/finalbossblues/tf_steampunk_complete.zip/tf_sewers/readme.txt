-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY - SEWERS TILESET
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading this tileset! 

This set is a bonus addition to the TIME FANTASY STEAMPUNK expansion.
It was previously released as a special download for patreon.

This tileset is a mini-expansion for the Time Fantasy RPG assets. It's compatible with all other graphics that I release in my Time Fantasy style. Can also be used as a standalone tileset.

This set includes versions formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as a regular tile-sheet based on a 16x16 grid.

-------------------------

Note for RPGMaker users: 
The waterfall tiles are a bit complicated because of the way that auto-tiles work. To make the best use out of them, you'll need to use the SHIFT button to copy and place specific animated tiles.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------