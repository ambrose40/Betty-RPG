-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 RUINED DUNGEONS EXPANSION
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading this asset pack!

This tileset pack was created as a reward goal for my Patrons.
It wouldn't be possible without your support!
To help fund more releases like this one, check out my Patreon page:
(there's a lot of new graphics to download for patrons too!)

patreon.com/finalbossblues

-------------------------

This is an expansion pack for the Time Fantasy RPG assets. 
The tiles in this pack will fit with all of my graphics in this style.

This expansion includes:
- Three new dungeon areas!
- Each dungeon has a terrain-layer tileset and an object-layer tileset.
- Animated water auto-tiles for each dungeon theme.

This pack includes versions of all graphics formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as a base sheet based on a 16x16 grid.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Patreon
 patreon.com/finalbossblues
Twitter
 @finalbossblues
Facebook
 finalbossblues
-------------------------