Hey thanks for buying my graphics pack!

TIME FANTASY: WINTER TILES

This pack is compatible with all graphics in my Time Fantasy RPG style.

The regular-sized graphics are included for general editing and work well in Tiled. 
They're also arranged in a straightforward 16x16 grid so you can re-organize them however fits your needs.

This pack also includes versions of these tiles formatted for use in RPGMaker VX/Ace and RPGMaker MV.


Notes:

This asset pack also includes some graphics that were part of previous packs (and variations on them). 
It's mostly some basic stuff that establishes the style, like the base grass tiles and the signposts etc. 
They're included to ensure that the expansion packs still have some context, so extras. :)

-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues