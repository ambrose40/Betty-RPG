-------------------------------------
        ::  TIME FANTASY  ::
    -=- CHARACTER SPRITE MINIS -=-
-------------------------------------

This is a special bonus expansion pack that is designed to work with multiple major Time Fantasy releases.

The mini-sprites in this pack are made to fit within a single tile-space. They're perfect for use on a world-map, or even as icons or tactics-style unit sprites.

The sprites found here will correspond with characters from:
- Time Fantasy (Original Set) (charas1-5, soldiers1-3)
- Time Fantasy: Monsters Expansion (charas6-8, horses, orcs)
- Future Fantasy Expansion (future1, future2, soldiers2-3)
- Free Bonus Release from the Time Fantasy website (monks)

Also included is a "base" sprite (no clothing) that can be build on for creating original characters.

------------------------- SIZES:

The character sprites in this pack are designed to fit in a 16x16 single-tile grid.

This pack includes versions of these sprites formatted for:
- 100% size for general use
- RPGMaker VX/Ace (200%) 
- RPGMaker MV/MZ (300%)

-------------------------

Thanks for downloading! I hope that you find these to be useful.
 - 5.18.2021

-------------------------
Time Fantasy Website
 timefantasy.net

itch Store Page
 finalbossblues.itch.io
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Patreon
 patreon.com/finalbossblues