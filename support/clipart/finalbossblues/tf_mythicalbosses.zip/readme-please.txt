-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 MYTHICAL MONSTERS PATRON PACK
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for your support!

This pack is a collection of sprites with a focus on classic mythical
monster types and monsters that will be useful as bosses.

This is an expansion pack for the Time Fantasy RPG assets.
The sprites in this pack will fit with all of my graphics in this style.
In particular this pack will be a good add-on to the Monsters expansion
and the Lich Crusades patron-exclusive.

------------------------
Some of the sprites in this pack have been previously released on patreon.
They're included because they're a good fit for the theme.

Previously-released Sprites:
- Dragon (Green and Red)
- Beholder
- Sasquatch and Snow Monster
- Hydras
- Harpies
- Ghost
- Mummy

New Sprites:
- Cerberus
- Centaurs (A, B, C)
- Medusa
- Boss: Chimera
- Boss: Drider
- Boss: Garuda
- Boss: Giant
- Boss: Kraken
- Boss: Statue West
- Boss: Statue East
- Boss: Kraken
- Dinosaur: Neckosaur
- Dinosaur: Pterosaur
- Dinosaur: Raptor
- Dinosaur: T-Rex

------------------------

Note: The BOSS sprites are mega-sized sprites that only have an "idle" animation
instead of the regular 4-directional walking animation.

Note 2: The DINOSAUR sprites also come with attack animations. They were originally
part of a special commission and I was given the chance to release them for patrons.
I hope you find them useful!

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------