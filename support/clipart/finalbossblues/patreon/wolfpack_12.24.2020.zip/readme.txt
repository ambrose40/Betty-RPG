-=-=-=- -==-=- -==-=- -==-=- -==-=-
          The WOLF PACK
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading these graphics! 

This set of assets is a FREE release for anybody to download. I created these sprites as a Christmas Present for everyone who has supported my work-- and anybody else who will find a use for them!
 
In the past, I've made free releases on Christmas that have holiday themes-- this time, I wanted to make something that would have more general use in your games. After considering some past patron suggestions, and thinking about where I want to go with future releases, I had the idea to put together these sprites with extended animation sets.

I call this set "The Wolf Pack" -- it's a collection of wolf sprites for RPGs. The highlight is that these sprites have a complete set of full eight-directional animations. Included are separate animations for walking, for running, as well as sitting and howling poses. There are three color variations for the wolves: gray, brown, and black.

There are also two color-palette styles: the "time fantasy" style, with colors designed to match with my series of Time Fantasy RPG assets, and a "full color" style which will be easier to fit in with different aesthetics.

I hope that you find a lot of use for these.

Merry Christmas!
- 12/24/2020

-------------------------

Special thanks to my wonderful patrons for making this present possible! - patreon.com/finalbossblues

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------