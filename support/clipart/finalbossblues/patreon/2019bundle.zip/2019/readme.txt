Downloaded from www.patreon.com/finalbossblues

Thanks for the wonderful and productive 2019!
Looking forward to a great 2020.