
	 -=-=-=-=-
  TIME FANTASY: ANIMALS 2
	 -=-=-=-=-

Thank you for buying this asset pack. This is an expansion pack for the Time Fantasy RPG assets. The sprites in this pack will fit with all of my graphics in this style.

This is the second collection of ANIMALS in my Time Fantasy series, with 60+ new animal sprites. This set is based on exotic and aquatic animals, to provide more variety for your game locations. I hope that you get a lot of use out of these!

This pack includes versions of these sprites formatted for use in RPGMaker VX/Ace and RPGMaker MV/MZ.

Note: The "$" in the filename is so RPGMaker reads the image as a single-character file. The other sheets are labeled with "8sheet" for organization: you can delete the "8sheet" from these filenames if you want, but the "$" in the single-sheets is necessary for RPGMaker.

Note 2: Some of the animal sprites in this pack have been previously released on patreon.

Have fun!

---------------------

This pack wouldn't be possible without support and suggestions from patrons.
  patreon.com/finalbossblues

Join up to access the huge archive of patron assets, and more every week!

---------------------

Twitter
   twitter.com/finalbossblues
Time Fantasy Website
   timefantasy.net
Artist's Website
   finalbossblues.com