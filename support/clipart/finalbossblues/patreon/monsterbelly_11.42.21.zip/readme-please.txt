-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY - INSIDE THE MONSTER'S BELLY - Expansion Pack
-==-=- -==-=- -==-=- -==-=- -==-=-

This release is only possible because of generous patrons. Seriously-- it was 
made directly using suggestions and ideas from patrons! 

Sign up to contribute to the next one. patreon.com/finalbossblues

-------------------------

This set includes a set of tilesets and animated sprites. They're all designed to work 
for a "inside the giant monster's belly" dungeon theme for an RPG.

In addition to general sheets that use a 16x16 base grid, I've included versions formatted for 
use in RPGMakerVX/Ace and RPGMakerMZ/MV.

Below are notes and instructions for some of the individual sheets included in this set:

---

"Giant Worm Mouth":
There are two variations that can be used with specific terrain types based on the world map tiles: 
desert and grass. They have some extra detail to blend into the world.

This set can be used as a big entrance from the world-map into the belly dungeon... OR it could be
used on a normal map as a regular-sized enemy that comes up from the ground.

The sheets are arranged like this: the first column is a 4-frame animation, the second column is a 
single frame of the "up but mouth closed" position, the third column is another 4-frame animation 
of the mouth opening, and the last column is a single frame of the "open" position.

The single-frame columns with repeated frames are arranged that way for ease of use in RPGMaker. 
If you're not using RPGMaker, then you can delete some of the repeated frames or just re-arrange 
however works best for you.

---

"The Heart":
- It's a simple three-frame animation of a heartbeat. The variations are the shadow: 
no shadow, full shadow, and 50% alpha shadow.

---

"Tentacles"
- There are repeated frames and animations on this sheet for the sake of RPGMaker's expected sheet 
format. If you're not using RPGMaker, then you can disregard or delete the repeated frames.

---

"Bacteria Cell Monsters": 
- If you're using RPGMaker, choose one direction and use the "direction fix" option so it doesn't 
swap between sprites.

---

Thanks for your support!

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------