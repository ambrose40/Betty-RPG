Downloaded from www.patreon.com/finalbossblues

Thanks for the productive 2021-- Looking forward to a great 2022!

------

(if you somehow got this and you're not a patron -- be a pal throw me a few bones and sign up if you like the content)