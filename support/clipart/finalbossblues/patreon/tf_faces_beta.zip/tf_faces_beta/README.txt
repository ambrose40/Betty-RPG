=======

TIME FANTASY: "BETA" FACES

=======

Thanks for downloading!

I've released these for PATRONS as "beta" art for the Time Fantasy faces collection that I am working on.

I think that these are low quality and I am currently working on an improved set 
for the final release of the TF Faces. For now, you're welcome to use these as placeholders 
(or for anything else if you actually like them LOL).

Thanks!

 ~ www.patreon.com/finalbossblues