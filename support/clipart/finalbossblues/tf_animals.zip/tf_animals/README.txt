TIME FANTASY: ANIMALS

Thank you for buying this asset pack!

This is an expansion pack for the Time Fantasy RPG assets. The sprites in this pack will fit with all of my graphics in this style.


This pack also includes versions of these sprites formatted for use in RPGMaker VX/Ace and RPGMaker MV.


Note:
- animals1.png (the sheet with cats and dogs) was previously released as a free update on timefantasy.net. 
- horse1.png was previously released in the "Time Fantasy: Monsters" asset pack.
Both of these assets have been included in this pack as extras because they fit the theme. :)

Have fun!

---------------------
Time Fantasy Website
   timefantasy.net
Artist's Website
   finalbossblues.com