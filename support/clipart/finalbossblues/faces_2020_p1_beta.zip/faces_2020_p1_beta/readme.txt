-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
-==-=- -==-=- -==-=- -==-=- -==-=-
 FACES - SET ONE - PATREON BETA
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading! This is a a special preview release for patrons.

These faces aren't necessarily final- let me know if there are problems that I need to fix before the final release.

The faces included in this set correspond to the characters in the base Time Fantasy character sprite pack: charasets 1-5.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------