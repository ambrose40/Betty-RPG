-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY - FAIRY FOREST - Tileset Expansion Pack
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for your support! This release is only possible because of patrons. 

-------------------------

This is an expansion pack for the Time Fantasy RPG assets. These tiles will fit with all of my graphics in this style.

This set includes versions formatted for use in RPGMaker VX/Ace and RPGMaker MV. Also includes
a regular tile-sheet based on a 16x16 grid, in a RPGMaker format as well as a general master tilesheet.

-------------------------

BONUS SPRITES: This set also includes some bonus character sprites that were previously released on Patreon. 
These were added as a bonus because they fit the theme of this set.
- Fairies
- Bugs and Butterflies
- Dryad Character

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------