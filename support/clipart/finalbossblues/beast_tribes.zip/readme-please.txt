-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY - BEAST TRIBES - Character Expansion Pack
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for your support!
This release is only possible because of generous patrons.

-------------------------

This is an expansion pack for the Time Fantasy RPG assets.
The sprites in this pack will fit with all of my graphics in this style.

This pack is a collection of sprites in five fantasy races based on animals. The five tribes are:
	- Wolf Men (Kobolds)
	- Cat Men
	- Lizard Men
	- Bird Men
	- Fish Men

Each tribe has a set with 8 regular character sprites. 

In addition, each tribe has one special hero character. The hero characters also have additional animations
for emotions, and a sheet with side-view RPG-style battle animations.

The included side-view battle sprites are arranged in the format used by RPG Maker MV.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------