-------------------------
     TIME FANTASY
-------------------------

House Tileset Updates!

This update improves the houses and buildings that can be made with the Time Fantasy graphics. 
In addition to being visually updated, they are vastly more flexible, allowing for a wider variety of houses to be 
crafted out of these tiles, including multiple stories and mix-and-match roof shapes. 

There are three new object-layer tilesets: updated house bases, ruined house bases, and improved rooftops. 
The rooftops come in 6 different colors (plus snow).

In addition to a regular versatile tileset, versions are included for RPGMaker VX/Ace and RPGMaker MV.

Thanks!

-------------------------
Time Fantasy Website
  timefantasy.net
-------------------------
Artist's Website
  finalbossblues.com
-------------------------
Twitter
  @finalbossblues
Facebook
  finalbossblues
Patreon
  patreon.com/finalbossblues
-------------------------