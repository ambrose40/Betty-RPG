INFO:

This demo represents the final destination of a long tutorial series, but that series is still being developed! Contents may change,
bugs may exist and may be fixed at a later date, features may be added. Check the itch.io page regularly for updates.

CONTROLS:

WASD/Arrows to move and navigate menus
Escape to pause the game
Space to talk/use/roll
Shift to attack
Control to use item
E to cycle equipped item

CREDITS:

Fonts used in this project include m5x7 and m3x6 by Daniel Linssen	
Find more works by daniel at: https://managore.itch.io/

Everything else by Shaun Spalding