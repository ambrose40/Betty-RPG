----------------------------
      ::  MECHA WAR  ::
----------------------------

This pack includes four mech robot characters. Each mech has the following sprites:
- Standing
- Standing with Folded Wing Attachment
- Flying, Wings Open (Non-Animated)
- Flying, Wings Open (Animated Jet Engine Fire)

In addition to the mech robots, the pack also includes a sheet of fighter ships. There are 4 ship designs:
- Jet fighter
- Bomber
- Alien Fighter
- Alien Bomber
- Each design comes with two color variations for a total of 8 ships on the sheet.

Also included is an additional sheet with "shots" projectiles designed to work with the fighter ships: 
- lasers and bullets in various combinations and colors

------------------------- COLORS:

The set comes in two different color variations: 

The first is the "full color", which is the normal version best for general use.
It doesn't use a specific overall color palette.

The "limited color" version matches the muted colors of the Time Fantasy assets.
The sprites in this set will match visually with all of my graphics in the TF style.

------------------------- SIZES:


This pack includes versions of these sprites formatted for:
- 100% size for general use
- RPGMaker VX/Ace (200%) 
- RPGMaker MV/MZ (300%)

The frame size for the mech robots is 80x80. 
The frame size for the fighters and projectiles is 32x32.

-------------------------

Thanks for downloading! I hope that you find these to be useful.
 - 4.1.2021

-------------------------
Time Fantasy Website
 timefantasy.net

itch Store Page
 finalbossblues.itch.io
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Patreon
 patreon.com/finalbossblues