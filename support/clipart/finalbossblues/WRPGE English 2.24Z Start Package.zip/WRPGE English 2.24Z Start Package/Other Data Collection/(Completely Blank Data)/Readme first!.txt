This Data folder has no Base System, only the minimal amount of initial data.

By copying this "Data" folder, you can start from a complete blank slate.

Before you start the Editor, replace the original "Data" folder in the location of Editor.exe with this "Data" folder.
You can start creating your game from this data.

* We recommend changing the name of the original Data folder instead of "overwrite" or deleting it,
then please copy the "Data" folder from here.