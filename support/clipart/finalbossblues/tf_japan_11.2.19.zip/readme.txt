-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 JAPAN TILESET EXPANSION
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for buying this asset pack!

This is an expansion pack for the Time Fantasy RPG assets. 
The tiles in this pack will fit with all of my graphics in this style.

This pack includes versions of all graphics formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as a basesheet based on a 16x16 grid.

Note: 
These previously-released graphics were included as a bonus because they fit the theme:
- The "samurai" and "ninja" sprites and battlers were originally released on patreon. 
- The "fish" sprites were originally released on patreon.
- The "monks" sprites were originally released as a freebie on timefantasy.net.

-------------------------
Time Fantasy Website
   timefantasy.net
-------------------------
Artist's Website
   finalbossblues.com
Twitter
   @finalbossblues
Patreon
   patreon.com/finalbossblues
-------------------------