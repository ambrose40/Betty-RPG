Hey thanks for supporting me on Patreon!
	(or if you got this pack in some other way, thanks for downloading it!)

TIME FANTASY: LICH CRUSADES

This character pack is compatible with all graphics in my Time Fantasy RPG style.

This pack includes 32 new character sprites:
-?8 undead/skeleton soldiers.
-Elemental (fire and ice) skeletons and lich-lords.
-Two necromancers (male and female) with human and undead forms.
-8 crusader/paladin characters.
-8 angels (including a dark angel and a fallen angel)
-(The angels come with and without wings, so they can be used as regular characters)!

This pack includes versions of these sprites formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as sprite sheets in a regular 100% size.

Have fun!

-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues