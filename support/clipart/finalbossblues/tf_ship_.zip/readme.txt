-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 SHIPS EXPANSION
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for buying this asset pack!

This is an expansion pack for the Time Fantasy RPG assets. 
The tiles in this pack will fit with all of my graphics in this style.

This expansion includes:
- Terrain-layer tilesets for building ships (vertical, east, west, and interior)
- Object-layer tileset with masts, sails, cannons, and more!
- Animated water/wave graphics for use at the bottom of the ship.
- BONUS: Four pirate character sprites in the Time Fantasy style.
- Also included: a four-frame sea background tile (based on the original water tiles in Time Fantasy)

This pack includes versions of all graphics formatted for use in RPGMaker VX/Ace and RPGMaker MV, 
as well as a basesheet based on a 16x16 grid.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------