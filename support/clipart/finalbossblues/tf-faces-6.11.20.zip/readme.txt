-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
-==-=- -==-=- -==-=- -==-=- -==-=-
 FACES
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for downloading!

Finally-- face portraits for the Time Fantasy characters! This set includes over 100 unique faces, designed specifically for the Time Fantasy series of pixel-art assets. Complete your collection with face sets for heroes, villains, and orcs! 

This set matches characters from the base Time Fantasy character set as well as characters from the Time Fantasy: Monsters expansion.

-------------------------

The faces included in this set correspond to the characters in the base Time Fantasy character sprite pack: chara 1-5, military 1-3, and the characters in the Time Fantasy Monsters expansion: chara 6-8, and orcs 1-2.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------