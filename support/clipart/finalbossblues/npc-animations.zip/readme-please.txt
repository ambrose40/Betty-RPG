-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 ANIMATED NPCS PACK
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for your support!

This pack is a collection of NPC sprites, with a focus on unique action animations to make your world more lively.

This is an expansion pack for the Time Fantasy RPG assets. The sprites in this pack will fit with all of my graphics in this style.
In particular this pack is designed to expand on sprites from the base Time Fantasy characters pack and the Monsters expansion.

------------------------
Some of the sprites in this pack have been previously released on patreon.
They're included because they're a good fit for the theme, and they have been expanded with additional animations.

-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------