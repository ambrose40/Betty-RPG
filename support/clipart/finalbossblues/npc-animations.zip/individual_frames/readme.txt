For the individual frames, the middle frame (2) is the idle frame in most cases.

When animating a three-frame loop, repeat the middle frame for a ping-pong style animation.