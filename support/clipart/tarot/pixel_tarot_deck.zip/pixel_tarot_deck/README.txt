-=-=-=-
PIXEL TAROT CARD DECK
-==-=-

Thank you for buying this asset pack!

The pixel tarot deck includes every card in the tarot deck, major arcana and all four suits of minor arcana. 
Everything is drawn in a classic 16-bit pixel artstyle.

The individual cards are 48x80 pixels. The files themselves are 58x90 with a transparent bleed.
Also includes a card back and frames for a spinning animation and a well-organized PSD file. 

In this pack:
- all 78 Cards in a Tarot deck
- individual .PNG files for each card (Major and Minor Arcana)
- .PNG file for card back
- .PNG frames for card spin and flash animations
- organized .PSD file with all cards and animations for use in Adobe Photoshop




-------------------------
Artist's Website
 finalbossblues.com
 timefantasy.net
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------

