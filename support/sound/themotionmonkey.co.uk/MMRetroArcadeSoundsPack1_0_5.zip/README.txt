The Motion Monkey Free Retro Arcade Sounds Pack v1.0.5

� 2015-2017 The Motion Monkey

All sounds are original recordings by The Motion Monkey.
If you want to share them around, then please share the download page on our website
(http://www.themotionmonkey.co.uk/free-resources/retro-arcade-sounds/) and let people download the latest version from there.

The sound pack is now under CC0, which means it's no longer strictly a requirement to include a credit on any work that uses the sounds. This was done to make it easier for you to use them. Of course if you do want to give a credit, or provide a link on your website that would be very much appreciated, but not a requirement.

Thanks.

To the extent possible under law, The Motion Monkey has waived all copyright and related or neighboring rights to The Motion Monkey Free Retro Arcade Sounds Pack v 1.0.5. This work is published from: United Kingdom. To view a copy of the CC0 documentation, visit https://creativecommons.org/publicdomain/zero/1.0/.